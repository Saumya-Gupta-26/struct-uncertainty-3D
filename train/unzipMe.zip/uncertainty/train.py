import torch
import numpy as np
import argparse, json
import os, glob, sys, shutil
from time import time

from dataloader import Dataset3D_SegDump_OnlineLoad

from dmt_trainer import getData_train, getData_val
from unc_model import UncertaintyModel
from utilities import MSE_VAR

def parse_func(args):
    ### Reading the parameters json file
    print("Reading params file {}...".format(args.params))
    with open(args.params, 'r') as f:
        params = json.load(f)

    mydict = {}
    mydict['num_classes'] = int(params['common']['num_classes'])
    mydict["unc_checkpoint_restore"] = params['common']['unc_checkpoint_restore'] # if you want to resume training from a checkpoint, provide the path ; leave it empty if you want to train from scratch

    mydict['data_dir'] = params['train']['data_dir']
    mydict['train_datalist'] = params['train']['train_datalist']
    mydict['validation_datalist'] = params['train']['validation_datalist']
    mydict['output_folder'] = params['train']['output_folder']
    mydict['learning_rate'] = float(params['train']['learning_rate'])
    mydict['num_epochs'] = int(params['train']['num_epochs']) + 1
    mydict['save_every'] = params['train']['save_every']
    mydict['crop_size'] = params['train'].get('crop_size', 64)


    print(mydict)
    return mydict


def set_seed(): # reproductibility 
    seed = 0
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    np.random.seed(seed)

def force_cudnn_initialization():
    s = 32
    dev = torch.device('cuda')
    torch.nn.functional.conv2d(torch.zeros(s, s, s, s, device=dev), torch.zeros(s, s, s, s, device=dev))

def train_func_3d(mydict):
    # Reproducibility, and Cuda setup
    set_seed()
    device = torch.device("cuda")
    print("CUDA device: {}".format(device))

    if not torch.cuda.is_available():
        print("WARNING!!! You are attempting to run training on a CPU (torch.cuda.is_available() is False). This can be VERY slow!")

    force_cudnn_initialization()

    if not os.path.exists(mydict['output_folder']):
        os.makedirs(mydict['output_folder'])

    if not os.path.exists(os.path.join(mydict['output_folder'],'inputs')):
        shutil.copytree('inputs/', os.path.join(mydict['output_folder'],'inputs'))
    
    if not os.path.exists(os.path.join(mydict['output_folder'],'output')):
        os.makedirs(os.path.join(mydict['output_folder'], 'output'))

    # Train and Val Data       
    training_set = Dataset3D_SegDump_OnlineLoad(mydict['data_dir'], mydict['train_datalist'], task="train", crop_size=mydict['crop_size'])
    validation_set = Dataset3D_SegDump_OnlineLoad(mydict['data_dir'], mydict['validation_datalist'], task="val", crop_size=mydict['crop_size']) 
    n_channels = 1 
    in_channels = 3 
    
    
    training_generator = torch.utils.data.DataLoader(training_set,batch_size=1,shuffle=True,num_workers=2, drop_last=True)
    validation_generator = torch.utils.data.DataLoader(validation_set,batch_size=1,shuffle=False,num_workers=2, drop_last=False)

    unc_regressor = UncertaintyModel(in_channels=in_channels, num_features=36, hidden_units=48).float().to(device)

    # Optimizer
    optimizer = torch.optim.Adam(unc_regressor.parameters(), lr=mydict['learning_rate'], weight_decay=0)

    # Load checkpoint (if specified)
    if mydict['unc_checkpoint_restore'] != "":
        checkpoint = torch.load(mydict['unc_checkpoint_restore'], map_location=device)
        unc_regressor.load_state_dict(checkpoint['model_state_dict'])
        print("loaded checkpoint! {} from epoch {}".format(mydict['unc_checkpoint_restore'], checkpoint['epoch']))

    # Losses
    unc_loss_func = MSE_VAR()
    
    # Train loop
    best_dict = {'epoch': 0, 'val_loss': None}
    print("Let the training begin!")    

    for epoch in range(mydict['num_epochs']):
        torch.cuda.empty_cache() # cleanup
        unc_regressor.to(device).train()

        avg_train_loss = 0.0
        cntvar = 0
        epoch_start_time = time()

        for step, (patch, y_patchlikelihood, mask, _) in enumerate(training_generator): 
            optimizer.zero_grad()

            patch = patch.to(device)
            mask = torch.squeeze(mask.to(device),dim=1)
            y_patchlikelihood = y_patchlikelihood.to(device)

            imgbatch, unc_input, unc_gt = getData_train(mydict['num_classes'], patch, y_patchlikelihood, mask)

            if unc_input is not None:
                imgbatch = imgbatch.float().to(device)
                unc_input = unc_input.float().to(device)
                unc_gt = unc_gt.float().to(device)

                unc_pred_mu, unc_pred_sigma = unc_regressor(imgbatch,unc_input)
                unc_pred_mu = torch.squeeze(unc_pred_mu, dim=1)
                unc_pred_sigma = torch.squeeze(unc_pred_sigma, dim=1)
                
                loss_val = unc_loss_func(unc_pred_mu, unc_pred_sigma, unc_gt)
                avg_train_loss += loss_val
                cntvar+=1

                loss_val.backward()
                optimizer.step()

        if cntvar!=0:
            avg_train_loss /= cntvar

        epoch_end_time = time()
        print("Epoch {} took {} seconds.\nAverage training loss: {}\nNumber of samples in this epoch {}".format(epoch, epoch_end_time-epoch_start_time, avg_train_loss, cntvar))
        with open(os.path.join(mydict['output_folder'], "training_log.txt"), "a") as log_file:
            log_file.write("\n\n\nEpoch {} took {} seconds.\nAverage training loss: {}\nNumber of samples in this epoch {}".format(epoch, epoch_end_time-epoch_start_time, avg_train_loss, cntvar))

        validation_start_time = time()
        with torch.no_grad():
            #unc_regressor.eval() # commenting because we want to keep dropout
            validation_iterator = iter(validation_generator)
            avg_val_loss = 0.0
            cntvar = 0
            for _ in range(len(validation_generator)):
                x, y_patchlikelihood, y_gt, _ = next(validation_iterator)
                x = x.to(device, non_blocking=True)
                y_patchlikelihood = y_patchlikelihood.to(device, non_blocking=True)
                y_gt = y_gt.to(device, non_blocking=True)

                imgbatch, unc_input, unc_gt = getData_val(mydict['num_classes'], x, y_patchlikelihood, y_gt)

                if unc_input is not None:
                    imgbatch = imgbatch.float().to(device)
                    unc_input = unc_input.float().to(device)
                    unc_gt = unc_gt.float().to(device)

                    unc_pred_mu, unc_pred_sigma = unc_regressor(imgbatch,unc_input)
                    unc_pred_mu = torch.squeeze(unc_pred_mu, dim=1)
                    unc_pred_sigma = torch.squeeze(unc_pred_sigma, dim=1)
                    
                    avg_val_loss -= unc_loss_func(unc_pred_mu, unc_pred_sigma, unc_gt)
                    #negative because we maximize val_loss while MSE_VAR is a minimization objective
                    cntvar+=1

            if cntvar!=0:
                avg_val_loss /= cntvar

        validation_end_time = time()
        print("End of epoch validation took {} seconds.\nAverage validation loss: {}\nNumber of samples in this val-loop: {}\nLearning rate: {}".format(validation_end_time - validation_start_time, avg_val_loss, cntvar, optimizer.param_groups[0]['lr']))

        # check for best epoch and save it if it is and print
        checkpoint_dict = {
            'epoch': epoch,
            'model_state_dict': unc_regressor.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'loss': avg_val_loss,
        }

        # check for best epoch and save it if it is and print
        if epoch == 0 or best_dict['val_loss'] < avg_val_loss:
            best_dict['epoch'] = epoch
            best_dict['val_loss'] = avg_val_loss
            torch.save(checkpoint_dict, os.path.join(mydict['output_folder'], "uncertainty_model_best.pth"))
            
        print("Best epoch so far: {}\n".format(best_dict))
        # save checkpoint for save_every
        if epoch % mydict['save_every'] == 0:
            torch.save(checkpoint_dict, os.path.join(mydict['output_folder'], "uncertainty_model_epoch" + str(epoch) + ".pth"))

        with open(os.path.join(mydict['output_folder'], "training_log.txt"), "a") as log_file:
            log_file.write("\nEnd of epoch validation took {} seconds.\nAverage validation loss: {}\nNumber of samples in this val-loop: {}\nLearning rate: {}".format(validation_end_time - validation_start_time, avg_val_loss, cntvar, optimizer.param_groups[0]['lr']))
            log_file.write("\nBest epoch so far: {}\n".format(best_dict))




if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--params', type=str, help="Path to the parameters file")
    
    if len(sys.argv) == 1:
        print("Path to parameters file not provided. Exiting...")

    else:
        args = parser.parse_args()
        mydict = parse_func(args)

    train_func_3d(mydict)
