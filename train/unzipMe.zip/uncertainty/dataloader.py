import torch
import imageio
import os, glob, sys
import numpy as np
import random
import pdb

class Dataset3D_SegDump_OnlineLoad(torch.utils.data.Dataset):
    def __init__(self, data_dir, listpath, task, crop_size):

        self.listpath = listpath
        self.task = task

        self.allFiles = []
        self.dataCPU = {}
        self.dataCPU['filepaths'] = [] # only stuff in cpu
        self.dataCPU['label'] = []
        self.dataCPU['img'] = []
        self.dataCPU['seg_likelihood'] = []

        self.img_dir = os.path.join(data_dir, "image")
        self.gt_dir = os.path.join(data_dir, "gt")
        self.likelihood_dir = os.path.join(data_dir, "seg_pred")


        self.crop_size = crop_size
        self.patches = []

        self.loadCPU() # only load the filename
        print("Length of dataset (num of 3D files): {}".format(len(self.allFiles)))
        print("Length of files on CPU: {}".format(len(self.dataCPU['filepaths'])))
        print("Length of dataset (num of 3D patches): {}".format(len(self.patches)))

    def loadCPU(self):
        with open(self.listpath, 'r') as f:
            mylist = f.readlines()
        mylist = [x.rstrip('\n') for x in mylist]

        gtpaths = []


        for _, gt_path in enumerate(mylist):
            gtpaths.append(os.path.join(self.gt_dir, gt_path))
        
        self.allFiles.extend(gtpaths)
        self.allFiles.sort(reverse=True)

        if self.task != "test":
            print("Computing patches...")
            self._precompute_patches()
            print("Finished computing patches...")


    def _precompute_patches(self):
        num_files = len(self.allFiles)
        cnt = 0
        N = 14  # Number of patches per file
        
        for idx, gt_path in enumerate(self.allFiles):
            gt = imageio.v3.imread(gt_path)
            print(gt.shape, gt_path)
            gt = gt / np.max(gt) if np.max(gt) > 0 else np.zeros_like(gt)

            if cnt <= num_files // 2:
                np_img, np_lh, np_gt = self.preprocess(gt_path)
                self.dataCPU['filepaths'].append(gt_path)
                self.dataCPU['label'].append(np_gt)
                self.dataCPU['img'].append(np_img)
                self.dataCPU['seg_likelihood'].append(np_lh)
                cnt += 1

            D, H, W = gt.shape
            
            # Calculate number of steps in each dimension to get roughly N patches
            # We want: steps_d * steps_h * steps_w ≈ N
            # Taking cube root since we want similar spacing in each dimension
            steps_per_dim = int(np.ceil(np.cbrt(N)))
            
            # Calculate step sizes
            step_d = max(1, (D - self.crop_size) // steps_per_dim)
            step_h = max(1, (H - self.crop_size) // steps_per_dim)
            step_w = max(1, (W - self.crop_size) // steps_per_dim)
            
            patches_this_file = []
            
            # Extract patches with calculated step sizes
            for z in range(0, D - self.crop_size + 1, step_d):
                for y in range(0, H - self.crop_size + 1, step_h):
                    for x in range(0, W - self.crop_size + 1, step_w):
                        patch_gt = gt[z:z+self.crop_size,
                                    y:y+self.crop_size, 
                                    x:x+self.crop_size]
                        
                        # Check if patch contains both classes
                        if len(np.unique(patch_gt)) == 2:
                            patches_this_file.append((idx, (z, y, x)))
            
            # If we have more than N valid patches, randomly sample N of them
            if len(patches_this_file) > N:
                patches_this_file = random.sample(patches_this_file, N)
            
            # Add the patches for this file to the main patches list
            self.patches.extend(patches_this_file)



    def interpolate(self,nparr):
        omin = 0
        omax = 1.0
        imin  = np.min(nparr)
        imax = np.max(nparr)

        return (nparr-imin)*(omax-omin)/(imax-imin) + omin


    def z_score_norm(self, x):
        meanval = x.mean()
        stdval = x.std()
        x = (x - meanval) / stdval
        return x

    def preprocess(self, gt_path):
        if 'Figure2' in gt_path:
            img_path = gt_path.replace(self.gt_dir, self.img_dir).replace('Binary_', '').replace('.tiff','.tif').replace('Binary', 'Raw')
            basename = os.path.basename(gt_path)
            likelihood_path = os.path.join(self.likelihood_dir, basename.replace('.tiff', '.npy'))
        elif 'Figure3' in gt_path:
            img_path = gt_path.replace(self.gt_dir, self.img_dir).replace("_GT.", "_IM.")
            basename = os.path.basename(gt_path)
            likelihood_path = os.path.join(self.likelihood_dir, basename.replace('.tiff', '.npy'))

        assert os.path.exists(gt_path)
        assert os.path.exists(img_path)
        assert os.path.exists(likelihood_path)

        arrayimage = imageio.v3.imread(img_path).astype(np.float32)
        arrayimage_gt = imageio.v3.imread(gt_path).astype(np.float32)
        array_lh = np.load(likelihood_path)
        if 'npz' in likelihood_path:
            array_lh = array_lh['probabilities'][1]

        assert arrayimage.shape == arrayimage_gt.shape #DHW
        assert arrayimage.shape == array_lh.shape

        
        arrayimage_norm = self.interpolate(arrayimage)
        
        arrayimage_gt_norm = arrayimage_gt / np.max(arrayimage_gt)

        return arrayimage_norm, array_lh, arrayimage_gt_norm


    def __len__(self): # total number of 3D patches
        if self.task != "test":
            return len(self.patches)
        else:
            return len(self.allFiles)


    def __getitem__(self, index): # return CDHW torch tensor
        if self.task != "test":
            volume_idx, (z, y, x) = self.patches[index]
            gt_path = self.allFiles[volume_idx]

            if gt_path in self.dataCPU['filepaths']:
                cpu_idx = self.dataCPU['filepaths'].index(gt_path) 
                np_img = self.dataCPU['img'][cpu_idx]
                np_gt = self.dataCPU['label'][cpu_idx]
                np_lh = self.dataCPU['seg_likelihood'][cpu_idx]
            else:
                np_img, np_lh, np_gt = self.preprocess(gt_path) #DHW

            np_img = np_img[z:z+self.crop_size, y:y+self.crop_size, x:x+self.crop_size]
            np_gt = np_gt[z:z+self.crop_size, y:y+self.crop_size, x:x+self.crop_size]
            np_lh = np_lh[z:z+self.crop_size, y:y+self.crop_size, x:x+self.crop_size]
        else:
            gt_path = self.allFiles[index]
            print(gt_path)
            # pdb.set_trace()
            np_img, np_lh, np_gt = self.preprocess(gt_path) #DHW

        torch_img = torch.unsqueeze(torch.from_numpy(np_img),dim=0) # CDHW
        torch_gt = torch.unsqueeze(torch.from_numpy(np_gt),dim=0) # CDHW
        torch_lh = torch.unsqueeze(torch.from_numpy(np_lh),dim=0) # CDHW

        return torch_img, torch_lh, torch_gt, gt_path 


