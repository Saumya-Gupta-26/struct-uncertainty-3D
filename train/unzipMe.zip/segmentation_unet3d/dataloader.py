import torch
import imageio
import SimpleITK as sitk
import os, glob, sys
import numpy as np
import random 

class Dataset3D_OnlineLoad(torch.utils.data.Dataset):
    def __init__(self, data_dir, listpath, task, crop_size, per_file=None):

        self.listpath = listpath
        self.task = task
        self.gt_dir = os.path.join(data_dir, "gt")
        self.img_dir = os.path.join(data_dir, "image")


        self.allFiles = []
        self.dataCPU = {}
        self.dataCPU['filepaths'] = [] # only stuff in cpu
        self.dataCPU['label'] = []
        self.dataCPU['img'] = []
        self.per_file = int(per_file) if per_file is not None else None

        self.crop_size = crop_size
        self.step_size = 3 * self.crop_size // 4

        self.intensity_scaling_param = [0, 4]
        self.patches = []

        self.loadCPU() # only load the filename
        print("Length of dataset (num of 3D volumes): {}".format(len(self.allFiles)))
        print("Length of files on CPU: {}".format(len(self.dataCPU['filepaths'])))
        print("Length of dataset (num of 3D patches): {}".format(len(self.patches)))

    def loadCPU(self):
        with open(self.listpath, 'r') as f:
            mylist = f.readlines()
        mylist = [x.rstrip('\n') for x in mylist]

        gtpaths = []
        for _, gt_path in enumerate(mylist):
            gtpaths.append(os.path.join(self.gt_dir, gt_path))
        
        self.allFiles.extend(gtpaths)
        self.allFiles.sort(reverse=True)

        print("Computing patches...")
        self._precompute_patches()
        print("Finished computing patches...")


    def _precompute_patches(self):

        num_files = len(self.allFiles)
        cnt = 0

        ext = self.allFiles[0].split('.')[-1]

        for idx, gt_path in enumerate(self.allFiles):
            if 'gz' in ext:
                gt = sitk.GetArrayFromImage(sitk.ReadImage(gt_path))
            else:
                gt = imageio.v3.imread(gt_path)
            print(gt.shape, gt_path)
            gt = gt / np.max(gt) if np.max(gt) > 0 else np.zeros_like(gt)

            if cnt <= num_files // 2:
                np_img, np_gt = self.preprocess(gt_path)
                self.dataCPU['filepaths'].append(gt_path)
                self.dataCPU['label'].append(np_gt)
                self.dataCPU['img'].append(np_img)
                cnt+=1

            D, H, W = gt.shape  # Now includes depth dimension

            if self.per_file is None:
                for z in range(0, D - self.crop_size + 1, self.step_size):
                    for y in range(0, H - self.crop_size + 1, self.step_size):
                        for x in range(0, W - self.crop_size + 1, self.step_size):
                            # Extract 3D patch
                            patch_gt = gt[z:z+self.crop_size,
                                        y:y+self.crop_size, 
                                        x:x+self.crop_size]
                            
                            # Check if patch contains both classes
                            if len(np.unique(patch_gt)) == 2:
                                self.patches.append((idx, (z, y, x)))
            else:
                # Get all possible patch coordinates
                valid_patches = []
                for z in range(0, D - self.crop_size + 1, self.step_size):
                    for y in range(0, H - self.crop_size + 1, self.step_size):
                        for x in range(0, W - self.crop_size + 1, self.step_size):
                            # Extract 3D patch
                            patch_gt = gt[z:z+self.crop_size,
                                        y:y+self.crop_size, 
                                        x:x+self.crop_size]
                            
                            # Check if patch contains both classes
                            if len(np.unique(patch_gt)) == 2:
                                valid_patches.append((z, y, x))
                
                # Randomly select patches if we have more valid patches than needed
                if len(valid_patches) > self.per_file:
                    selected_patches = random.sample(valid_patches, self.per_file)
                else:
                    # If we have fewer valid patches than needed, use all of them
                    selected_patches = valid_patches
                    print(f"Warning: Only found {len(valid_patches)} valid patches for volume {idx}, "
                        f"which is less than requested {self.per_file}")
                
                # Add selected patches to the list with volume index
                for patch_coord in selected_patches:
                    self.patches.append((idx, patch_coord))



    def interpolate(self,nparr):
        omin = 0
        omax = 1.0
        imin  = np.min(nparr)
        imax = np.max(nparr)

        return (nparr-imin)*(omax-omin)/(imax-imin) + omin


    def z_score_norm(self, x):
        meanval = x.mean()
        stdval = x.std()
        x = (x - meanval) / stdval
        return x

    def preprocess(self, gt_path):
        if 'Figure2' in gt_path:
            img_path = gt_path.replace(self.gt_dir, self.img_dir).replace('Binary_', '').replace('.tiff','.tif').replace('Binary', 'Raw')
        elif 'Figure3' in gt_path:
            img_path = gt_path.replace(self.gt_dir, self.img_dir).replace("_GT.", "_IM.")

        ext = gt_path.split('.')[-1]

        assert os.path.exists(gt_path)
        assert os.path.exists(img_path)

        if 'gz' in ext:
            arrayimage = sitk.GetArrayFromImage(sitk.ReadImage(img_path)).astype(np.float32)
            arrayimage_gt = sitk.GetArrayFromImage(sitk.ReadImage(gt_path)).astype(np.float32)
        else:
            arrayimage = imageio.v3.imread(img_path).astype(np.float32)
            arrayimage_gt = imageio.v3.imread(gt_path).astype(np.float32)

        assert arrayimage.shape == arrayimage_gt.shape #DHW
        
        arrayimage_norm = self.interpolate(arrayimage)
        
        arrayimage_gt_norm = arrayimage_gt / np.max(arrayimage_gt)

        return arrayimage_norm, arrayimage_gt_norm


    def __len__(self): # total number of 3D patches
        return len(self.patches)


    def __getitem__(self, index): # return CDHW torch tensor
        volume_idx, (z, y, x) = self.patches[index]
        gt_path = self.allFiles[volume_idx]

        if gt_path in self.dataCPU['filepaths']:
            cpu_idx = self.dataCPU['filepaths'].index(gt_path) 
            np_img = self.dataCPU['img'][cpu_idx]
            np_gt = self.dataCPU['label'][cpu_idx]
        else:
            np_img, np_gt = self.preprocess(gt_path) #DHW

        np_img = np_img[z:z+self.crop_size, y:y+self.crop_size, x:x+self.crop_size]
        np_gt = np_gt[z:z+self.crop_size, y:y+self.crop_size, x:x+self.crop_size]


        torch_img = torch.unsqueeze(torch.from_numpy(np_img),dim=0) # CDHW
        torch_gt = torch.unsqueeze(torch.from_numpy(np_gt),dim=0) # CDHW

        return torch_img, torch_gt, gt_path 


