import torch
import numpy as np
import argparse, json
import os, glob, sys
from time import time

from dataloader import Dataset3D_OnlineLoad
from model import UNet
from cldice import soft_dice, soft_cldice, TverskyLoss


def parse_func(args):
    ### Reading the parameters json file
    print("Reading params file {}...".format(args.params))
    with open(args.params, 'r') as f:
        params = json.load(f)

    mydict = {}
    mydict['num_classes'] = int(params['common']['num_classes'])
    mydict["checkpoint_restore"] = params['common']['checkpoint_restore'] # if you want to resume training from a checkpoint, provide the path ; leave it empty if you want to train from scratch

    
    mydict['data_dir'] = params['train']['data_dir']
    mydict['train_datalist'] = params['train']['train_datalist']
    mydict['validation_datalist'] = params['train']['validation_datalist']
    mydict['output_folder'] = params['train']['output_folder']
    mydict['crop_size'] = int(params['train']['crop_size'])
    mydict['train_batch_size'] = int(params['train']['train_batch_size'])
    mydict['val_batch_size'] = int(params['train']['val_batch_size'])

    mydict['per_file'] = params['train'].get('per_file', None) # number of patches to select per file ; if None, all possible patches are used

    mydict['learning_rate'] = float(params['train']['learning_rate'])
    mydict['loss_dice'] = float(params['train']['loss_dice'])
    mydict['loss_cldice'] = float(params['train']['loss_cldice'])
    mydict['loss_bce'] = float(params['train']['loss_bce'])
    mydict['loss_tversky'] = float(params['train']['loss_tversky'])

    mydict['lr_decay'] = False
    if params['train']['lr_decay'].lower() == "true":
        mydict['lr_decay'] = True

    mydict['num_epochs'] = int(params['train']['num_epochs']) + 1
    mydict['save_every'] = params['train']['save_every']


    print(mydict)

    if not os.path.exists(mydict['output_folder']):
        os.makedirs(mydict['output_folder'])

    return mydict


def set_seed(): # reproductibility 
    seed = 0
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    np.random.seed(seed)

def force_cudnn_initialization():
    s = 32
    dev = torch.device('cuda')
    torch.nn.functional.conv2d(torch.zeros(s, s, s, s, device=dev), torch.zeros(s, s, s, s, device=dev))


def log_message_func(message, log_file_path=None):
    """Print message and optionally write to log file."""
    print(message)
    if log_file_path:
        with open(log_file_path, "a") as log_file:
            log_file.write(message + "\n")


def train_func_3d(mydict):
    # Reproducibility, and Cuda setup
    set_seed()
    device = torch.device("cuda")
    print("CUDA device: {}".format(device))

    if not torch.cuda.is_available():
        print("WARNING!!! You are attempting to run training on a CPU (torch.cuda.is_available() is False). This can be VERY slow!")

    force_cudnn_initialization()

    # Train Data
    training_set = Dataset3D_OnlineLoad(mydict['data_dir'], mydict['train_datalist'], task="train", crop_size=mydict['crop_size'], per_file=mydict['per_file'])
    training_generator = torch.utils.data.DataLoader(training_set,batch_size=mydict['train_batch_size'],shuffle=True,num_workers=16, drop_last=True)

    # Validation Data
    validation_set = Dataset3D_OnlineLoad(mydict['data_dir'], mydict['validation_datalist'], task="val", crop_size=mydict['crop_size'])
    validation_generator = torch.utils.data.DataLoader(validation_set,batch_size=mydict['val_batch_size'],shuffle=False,num_workers=8, drop_last=False)

    # Network
    single_gpu_network = UNet(in_channels=1, out_channels=mydict['num_classes'], dim=3, start_filters=32)
    # network = single_gpu_network.to(device)
    network = torch.nn.DataParallel(single_gpu_network).to(device)
    

    # Optimizer and Learning-rate-scheduler
    optimizer = torch.optim.Adam(network.parameters(), lr=mydict['learning_rate'], weight_decay=0.00003)

    if mydict['lr_decay']:
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'max') #  in max mode LR will be reduced when the quantity monitored has stopped increasing. 

    # Load checkpoint (if specified)
    if mydict['checkpoint_restore'] != "":
        network.load_state_dict(torch.load(mydict['checkpoint_restore']), strict=True)
        print("loaded checkpoint! {}".format(mydict['checkpoint_restore']))

    # Losses
    loss_func_dict = {}
    loss_func_dict['dice'] = (soft_dice(), mydict['loss_dice'])
    loss_func_dict['cldice'] = (soft_cldice(), mydict['loss_cldice'])
    loss_func_dict['bce'] = (torch.nn.BCELoss(reduction='mean'), mydict['loss_bce'])
    loss_func_dict['tversky'] = (TverskyLoss(), mydict['loss_tversky'])


    print(f"Using the following loss configuration for training:\n{loss_func_dict}")

    val_loss_func = soft_dice()
    print("Using dice loss for validation")

    log_file_path = os.path.join(mydict['output_folder'], "training_log.txt")
    
    # Train loop
    best_dict = {}
    best_dict['epoch'] = 0
    best_dict['val_loss'] = None
    print("Let the training begin!")
    num_batches = len(training_generator)
    for epoch in range(mydict['num_epochs']):
        torch.cuda.empty_cache() # cleanup
        network.train() # after .eval() in validation

        avg_train_loss = 0.0
        individual_losses = {key: 0.0 for key in loss_func_dict.keys()}  # Initialize individual loss accumulators

        epoch_start_time = time()

        training_iterator = iter(training_generator)
        for _ in range(num_batches):
            optimizer.zero_grad()

            x, y_gt, _ = next(training_iterator)
            x = x.to(device, non_blocking=True)
            y_gt = y_gt.to(device, non_blocking=True)

            y_pred = torch.sigmoid(network(x))

            loss_val = 0.0
            for name, (loss_func, weight) in loss_func_dict.items():
                if weight != 0:
                    current_loss = loss_func(y_pred, y_gt)
                    weighted_loss = weight * current_loss
                    loss_val += weighted_loss
                    individual_losses[name] += current_loss.item()  # Store unweighted loss
                else:
                    individual_losses[name] += 0.0

            avg_train_loss += loss_val

            loss_val.backward()
            optimizer.step()

        # Calculate averages
        avg_train_loss /= num_batches
        for name in individual_losses:
            individual_losses[name] /= num_batches
        
        epoch_end_time = time()
        log_message = (
            f"\n\n\nEpoch {epoch} took {epoch_end_time-epoch_start_time:.2f} seconds.\n"
            f"Average training loss: {avg_train_loss:.4f}\n"
            "Individual losses:\n"
        )
        for name, loss in individual_losses.items():
            log_message += f"- {name}: {loss:.4f} (weight: {loss_func_dict[name][1]:.2f}, weighted: {loss * loss_func_dict[name][1]:.4f})\n"

        log_message_func(log_message, log_file_path)

        validation_start_time = time()
        with torch.no_grad():
            network.eval()
            validation_iterator = iter(validation_generator)
            avg_val_loss = 0.0
            for _ in range(len(validation_generator)):
                x, y_gt, _ = next(validation_iterator)
                x = x.to(device, non_blocking=True)
                y_gt = y_gt.to(device, non_blocking=True)

                y_pred = torch.sigmoid(network(x)) 
                avg_val_loss += (1. - val_loss_func(y_pred, y_gt)) # Converting loss to metric where higher is better

            avg_val_loss /= len(validation_generator)
            if mydict['lr_decay']:
                scheduler.step(avg_val_loss) # Learning rate decay

        validation_end_time = time()

        validation_message = (
            f"\nEnd of epoch validation took {validation_end_time - validation_start_time:.2f} seconds.\n"
            f"Average validation loss: {avg_val_loss:.4f}\n"
            f"Learning rate: {optimizer.param_groups[0]['lr']:.6f}"
        )
        log_message_func(validation_message, log_file_path)

        # check for best epoch and save it if it is and print
        checkpoint_dict = {
            'epoch': epoch,
            'model_state_dict': network.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'loss': avg_val_loss,
        }

        if epoch == 0:
            best_dict['epoch'] = epoch
            best_dict['val_loss'] = avg_val_loss
        else:
            if best_dict['val_loss'] < avg_val_loss: # Higher is better
                best_dict['val_loss'] = avg_val_loss
                best_dict['epoch'] = epoch
                torch.save(checkpoint_dict, os.path.join(mydict['output_folder'], "model_best.pth"))
            

        # Best epoch logging
        best_epoch_message = f"\nBest epoch so far: {best_dict}"
        log_message_func(best_epoch_message, log_file_path)

        # save checkpoint for save_every
        if epoch % mydict['save_every'] == 0:
            torch.save(checkpoint_dict, os.path.join(mydict['output_folder'], "model_epoch" + str(epoch) + ".pth"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--params', type=str, help="Path to the parameters file")
    
    if len(sys.argv) == 1:
        print("Path to parameters file not provided. Exiting...")

    else:
        args = parser.parse_args()
        mydict = parse_func(args)

    train_func_3d(mydict)
