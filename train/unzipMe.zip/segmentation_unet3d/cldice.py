import torch
import torch.nn as nn
import torch.nn.functional as F
from soft_skeleton import SoftSkeletonize
from skimage.morphology import skeletonize, skeletonize_3d
import numpy as np

#### METRICS ####

def cl_score(v, s):
    """[this function computes the skeleton volume overlap]

    Args:
        v ([bool]): [image]
        s ([bool]): [skeleton]

    Returns:
        [float]: [computed skeleton volume intersection]
    """
    return np.sum(v*s)/np.sum(s)


def clDice(v_p, v_l):
    """[this function computes the cldice metric]

    Args:
        v_p ([bool]): [predicted image]
        v_l ([bool]): [ground truth image]

    Returns:
        [float]: [cldice metric]
    """
    if len(v_p.shape)==2:
        tprec = cl_score(v_p,skeletonize(v_l))
        tsens = cl_score(v_l,skeletonize(v_p))
    elif len(v_p.shape)==3:
        tprec = cl_score(v_p,skeletonize_3d(v_l))
        tsens = cl_score(v_l,skeletonize_3d(v_p))
    return 2*tprec*tsens/(tprec+tsens)


def compute_dice(pred, gt):
    """
    Compute Dice coefficient for binary 2D tensors.
    Args:
        pred: Binary tensor of shape (H,W) with values 0 or 1
        gt: Binary tensor of shape (H,W) with values 0 or 1
    Returns:
        dice: Dice coefficient (float)
    """

    if not ((pred == 0) | (pred == 1)).all():
        raise ValueError("Predictions must be binary (0 or 1).")
    if not ((gt == 0) | (gt == 1)).all():
        raise ValueError("Ground truth must be binary (0 or 1).")

    # Compute intersection
    intersection = (pred * gt).sum()
    
    # Compute union (using definition of Dice)
    union = pred.sum() + gt.sum()
    
    # Handle empty masks
    if union == 0:
        if pred.sum() == 0 and gt.sum() == 0:
            return 1.0  # both are empty, return 1
        else:
            return 0.0  # one is empty, one is not, return 0
    
    # Compute Dice: 2|X∩Y|/(|X|+|Y|)
    dice = (2.0 * intersection) / union
    
    return dice.item()  # convert to Python scalar


#### LOSSES ####

class soft_cldice(nn.Module):
    def __init__(self, iter_=3, smooth = 1., exclude_background=True):
        super(soft_cldice, self).__init__()
        self.iter = iter_
        self.smooth = smooth
        self.soft_skeletonize = SoftSkeletonize(num_iter=10)
        self.exclude_background = exclude_background

    def forward(self, y_pred, y_true):
        # if self.exclude_background:
        #     y_true = y_true[:, 1:, :, :]
        #     y_pred = y_pred[:, 1:, :, :]
        skel_pred = self.soft_skeletonize(y_pred)
        skel_true = self.soft_skeletonize(y_true)
        tprec = (torch.sum(torch.multiply(skel_pred, y_true))+self.smooth)/(torch.sum(skel_pred)+self.smooth)    
        tsens = (torch.sum(torch.multiply(skel_true, y_pred))+self.smooth)/(torch.sum(skel_true)+self.smooth)    
        cl_dice = 1.- 2.0*(tprec*tsens)/(tprec+tsens) # minimize 1 - cldice coeff
        return cl_dice


def soft_dice_func(y_pred, y_true):
    """[function to compute dice loss]

    Args:
        y_true ([float32]): [ground truth image]
        y_pred ([float32]): [predicted image]

    Returns:
        [float32]: [loss value]
    """
    smooth = 1
    intersection = torch.sum((y_true * y_pred))
    coeff = (2. *  intersection + smooth) / (torch.sum(y_true) + torch.sum(y_pred) + smooth)
    return (1. - coeff) # minimize 1-dice coeff


class soft_dice(nn.Module):
    def __init__(self):
        super(soft_dice, self).__init__()

    def forward(self, y_pred, y_true):
        return soft_dice_func(y_pred, y_true)


class soft_dice_cldice(nn.Module):
    def __init__(self, iter_=3, alpha=0.5, smooth = 1., exclude_background=True):
        super(soft_dice_cldice, self).__init__()
        self.iter = iter_
        self.smooth = smooth
        self.alpha = alpha
        self.soft_skeletonize = SoftSkeletonize(num_iter=10)
        self.exclude_background = exclude_background

    def forward(self, y_pred, y_true):
        # if self.exclude_background:
        #     y_true = y_true[:, 1:, :, :]
        #     y_pred = y_pred[:, 1:, :, :]
        dice = soft_dice_func(y_pred, y_true)
        skel_pred = self.soft_skeletonize(y_pred)
        skel_true = self.soft_skeletonize(y_true)
        tprec = (torch.sum(torch.multiply(skel_pred, y_true))+self.smooth)/(torch.sum(skel_pred)+self.smooth)    
        tsens = (torch.sum(torch.multiply(skel_true, y_pred))+self.smooth)/(torch.sum(skel_true)+self.smooth)    
        cl_dice = 1.- 2.0*(tprec*tsens)/(tprec+tsens) # minimize 1 - cldice coeff
        return (1.0-self.alpha)*dice+self.alpha*cl_dice


class soft_bce_cldice(nn.Module):
    def __init__(self, iter_=3, alpha=0.5, smooth = 1., exclude_background=True):
        super(soft_bce_cldice, self).__init__()
        self.iter = iter_
        self.smooth = smooth
        self.alpha = alpha
        self.soft_skeletonize = SoftSkeletonize(num_iter=10)
        self.exclude_background = exclude_background
        self.bce_func = torch.nn.BCELoss(reduction='mean')

    def forward(self, y_pred, y_true):
        # if self.exclude_background:
        #     y_true = y_true[:, 1:, :, :]
        #     y_pred = y_pred[:, 1:, :, :]
        bce = self.bce_func(y_pred,y_true)
        skel_pred = self.soft_skeletonize(y_pred)
        skel_true = self.soft_skeletonize(y_true)
        tprec = (torch.sum(torch.multiply(skel_pred, y_true))+self.smooth)/(torch.sum(skel_pred)+self.smooth)    
        tsens = (torch.sum(torch.multiply(skel_true, y_pred))+self.smooth)/(torch.sum(skel_true)+self.smooth)    
        cl_dice = 1.- 2.0*(tprec*tsens)/(tprec+tsens) # minimize 1 - cldice coeff
        return (1.0-self.alpha)*bce+self.alpha*cl_dice




# class BoundaryLoss(torch.nn.Module):
# https://github.com/LIVIAETS/boundary-loss


class TverskyLoss(torch.nn.Module):
    def __init__(self, alpha=0.9, beta=0.1, smooth=1e-6):
        """
        alpha: weight of false positives
        beta: weight of false negatives
        smooth: Smoothing factor to avoid division by zero
        Typically beta > alpha to penalize false negatives more
        """
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.smooth = smooth

    def forward(self, y_pred, y_true):
        # Flatten predictions and targets
        y_pred = y_pred.view(-1)
        y_true = y_true.view(-1)
        
        # True Positives, False Positives & False Negatives
        tp = torch.sum(y_true * y_pred)
        fp = torch.sum((1 - y_true) * y_pred)
        fn = torch.sum(y_true * (1 - y_pred))
        
        # Tversky index
        numerator = tp + self.smooth
        denominator = tp + self.alpha * fp + self.beta * fn + self.smooth
        
        # Tversky loss
        loss = 1 - (numerator / denominator)
        
        return loss
